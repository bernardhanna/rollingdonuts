<?php

namespace Roots\Soil\Tests\Fixtures\Modules;

class CustomNameModule extends StubModule
{
    protected $name = 'foo-bar';
}
