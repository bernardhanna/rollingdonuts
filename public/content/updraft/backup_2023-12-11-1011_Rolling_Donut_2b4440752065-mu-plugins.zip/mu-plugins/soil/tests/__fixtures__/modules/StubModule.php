<?php

namespace Roots\Soil\Tests\Fixtures\Modules;

use Roots\Soil\Modules\AbstractModule;

class StubModule extends AbstractModule
{
    public function handle()
    {
        //--
    }
}
