<?php
/**
 * @Author: Bernard Hanna
 * @Date:   2023-07-04 16:53:05
 * @Last Modified by:   Bernard Hanna
 * @Last Modified time: 2023-08-18 14:40:59
 */

/**
 * Plugin Name: Register ACF Fields
 * Description: Registers ACF fields using ACF Builder.
 */
