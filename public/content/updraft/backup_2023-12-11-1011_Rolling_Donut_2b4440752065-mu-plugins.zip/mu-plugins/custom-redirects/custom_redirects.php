<?php
/**
 * @Author: Bernard Hanna
 * @Date:   2023-09-01 12:33:48
 * @Last Modified by:   Bernard Hanna
 * @Last Modified time: 2023-09-01 12:43:54
 */

/**
 * Plugin Name: Custom Redirects
 * Description: Handles custom redirects for the Rolling Donut website.
 * Version: 1.0
 * Author: Bernard Hanna
 */

function custom_redirects() {
    // Get the current request URI
    $request_uri = $_SERVER['REQUEST_URI'];

    // Path to the CSV file
    $csv_file_path = __DIR__ . '/redirects.csv';

    // Open the CSV file
    if (($handle = fopen($csv_file_path, 'r')) !== false) {
        // Skip the header row
        fgetcsv($handle);

        // Loop through each row in the CSV
        while (($data = fgetcsv($handle)) !== false) {
            $old_url = $data[0];
            $new_url = $data[1];

            // Check if the current request matches an old URL and redirect
            if ($request_uri === $old_url) {
                wp_redirect(home_url($new_url), 301);
                exit;
            }
        }

        // Close the CSV file
        fclose($handle);
    }
}

// Hook into 'template_redirect' action
add_action('template_redirect', 'custom_redirects');
